close all
clear all

%[fname pname]=uigetfile('*.txt');

%%Ellison
 
[FID,Field1,ID,Lat,Lon,yyyy,mm,dd,hh,mn,ss,Depth]=...
    textread(['north.txt'],...
    '%f %f %f %f %f %4u-%2u-%2uT %2u:%2u:%2uZ %f',...
    'headerlines',1,...
    'delimiter',',');

dn=datenum(yyyy,mm,dd,hh,mn,ss);

load north.mat

cor_time=SerialDay+datenum(00,00,00,10,00,00);

kk=0;

cor_soundings=zeros(1,length(dn));

for i=1:length(dn)

[r,c,V] = findnearest(dn(i),cor_time);

cor_soundings(:,kk+1)=Depth(i)-TimeSeries(c);

kk=kk+1;
end

cor_soundings=cor_soundings'; 
correct_depth=cor_soundings;
Time=dn;
M=[Time Lat Lon Depth correct_depth];
% 
dlmwrite('20190604_north_corrected_WaterDepth.txt',M,'delimiter',',','precision',20)